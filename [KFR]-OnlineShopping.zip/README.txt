-CustomConfig (You can edit every message in OnlineShopping.yml)
-DynamicConfig
-Ability to enable / disable commands
-eBay Search
-Amazon Search
-AliExpress Search
-No API Keys required.
-Ability to add own referrals to URLS


Spoiler: Configuration File
Code:
Enabled:
amazon: true
ebay: true
aliexpress: true
Amazon:
Domain: https://www.amazon.co.uk/s?k=
¬3: You can change co.uk to .com or .ca etc
Command:
name: amazon
description: allows you to search amazon
category: other
aliases:
- amazonie
Messages:
InvalidArgs:
Title: Amazon Search
Description: "Usage: `{prefix}{command} <query>`"
Search:
Title: Amazon Search
Description: |-
Search on Amazon for `{query}`
[Click to go]({output})
eBay:
Domain: https://www.ebay.co.uk/sch/i.html?_nkw=
¬3: You can change co.uk to .com or .ca etc
Command:
name: ebay
description: allows you to search eBay
category: other
aliases:
- ebayy
Messages:
InvalidArgs:
Title: eBay Search
Description: "Usage: `{prefix}{command} <query>`"
Search:
Title: eBay Search
Description: |-
Search on Amazon for `{query}`
[Click to go]({output})